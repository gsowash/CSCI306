
public class Warrior extends Player {
	@SuppressWarnings("unused")
	private int strength;
	public void attack(Player opponent){}
	public void workout(){}
}
