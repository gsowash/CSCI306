
public class ScoreCard {
	@SuppressWarnings("unused")
	private int score;
	public void displayScore(){}
}
