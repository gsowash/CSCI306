package mainpackage;

public class Envelope {
	public Envelope(int dollars, int quarters, int dimes, int nickels,
			int pennies) {
		super();
		this.dollars = dollars;
		this.quarters = quarters;
		this.dimes = dimes;
		this.nickels = nickels;
		this.pennies = pennies;
	}

	public int dollars, quarters, dimes, nickels, pennies;

	
//
//	public void setDollars(int dollars, int quarters,int dimes,int nickles,int pennies) 
//	{
//		this.dollars = dollars;
//		this.quarters = quarters;
//		this.dimes = dimes;
//		this.nickels = nickels;
//		this.pennies = pennies;
//	}

	
}
