import java.util.ArrayList;


public class Game {
	@SuppressWarnings("unused")
	private ArrayList<Player> players=new ArrayList<Player>(0);
	public static final int MAX_PLAYERS = 10;
	public void oneTurn(){};
}
