
public class Location {
	@SuppressWarnings("unused")
	private int x;
	@SuppressWarnings("unused")
	private int y;
	public void move (int dx,int dy){}
}
