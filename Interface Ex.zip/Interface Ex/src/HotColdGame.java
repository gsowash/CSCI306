
public class HotColdGame extends Guessable 
{
	public static void main(String args[])
	{
	System.out.println("In Hot/Cold");
	}
}
