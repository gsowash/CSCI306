
public class Navigator extends Player 
{
	@SuppressWarnings("unused")
	private int vision;
	public Direction findPath(Location teamLoc){return Direction.NORTH;}
	
}
